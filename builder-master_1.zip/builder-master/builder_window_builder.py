#-------------------------------------------------
#   File builder_window_builder.py
#-------------------------------------------------

import bpy

#-------------------------------------------------
#   Create class Window
#-------------------------------------------------

class create_window(bpy.types.Operator):
    
    bl_idname = 'mesh.builder_window_builder'
    bl_label = 'Add Window'
    bl_description = 'Add a window object to current scene'
    bl_options = {'REGISTER', 'UNDO'}
    bl_category = 'Builder'
    
    def draw(self, context):
        
        self.layout.label('Look in the properties panel for more configuration options', icon = 'INFO')
        
    def execute(self, context):
        
        create_object(self, context)
        self.report({'INFO'}, 'Exceution succesful')
        return {'FINISHED'}

def generate_components(self, context):
    
    # 1. Create the main object
    
    mesh = bpy.data.meshes.new('WindowMesh')
    mesh_object = bpy.data.objects.new('Window', mesh)
    context.scene.objects.link(mesh_object)
    mesh_object.location = context.scene.cursor_location
    
    mesh_object.window_property.add()
    
    w = mesh_object.window_property[0].window_frame_width / 2
    h = mesh_object.window_property[0].window_frame_height / 2
    d = mesh_object.window_property[0].window_frame_depth / 2
    t = mesh_object.window_property[0].window_frame_thickness
    gt = mesh_object.window_property[0].glass_pane_thickness / 2
    
    vertices = [
                (-w, -d, h),
                (w, -d, h),
                (w, -d, -h),
                (-w, -d, -h),
                (-w+t, -d, h-t),
                (w-t, -d, h-t),
                (w-t, -d, -h+t),
                (-w+t, -d, -h+t),
                (-w, d, h),
                (w, d, h),
                (w, d, -h),
                (-w, d, -h),
                (-w+t, d, h-t),
                (w-t, d, h-t),
                (w-t, d, -h+t),
                (-w+t, d, -h+t)
    ]
    
    faces = [
            (0, 4, 5, 1),
            (1, 5, 6, 2),
            (2, 6, 7, 3),
            (3, 7, 4, 0),
            (8, 9, 13, 12),
            (9, 10, 14, 13),
            (10, 11, 15, 14),
            (11, 8, 12, 15),
            (0, 1, 9, 8),
            (1, 2, 10, 9),
            (2, 3, 11, 10),
            (3, 0, 8, 11),
            (4, 12, 13, 5),
            (5, 13, 14, 6),
            (7, 6, 14, 15),
            (4, 7, 15, 12)
    ]
    
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    mesh_object.select = True
    context.scene.objects.active = mesh_object
    
    # 2. Create the glass pane
    
    mesh_1 = bpy.data.meshes.new('WindowPaneMesh')
    mesh_object_1 = bpy.data.objects.new('WindowPane', mesh_1)
    context.scene.objects.link(mesh_object_1)
    mesh_object_1.location = mesh_object.location
    
    vertices = [
                (-w+t, -gt, h-t),
                (w-t, -gt, h-t),
                (w-t, -gt, -h+t),
                (-w+t, -gt, -h+t),
                (-w+t, gt, h-t),
                (w-t, gt, h-t),
                (w-t, gt, -h+t),
                (-w+t, gt, -h+t)
    ]
    
    faces = [
            (0, 3, 2, 1),
            (4, 5, 6, 7),
            (0, 1, 5, 4),
            (1, 2, 6, 5),
            (2, 3, 7, 6),
            (3, 0, 4, 7)
    ]
    
    mesh_1.from_pydata(vertices, [], faces)
    mesh_1.update()
    
    # 3. Create bounding box
    
    mesh_2 = bpy.data.meshes.new('WindowBoundingBoxMesh')
    mesh_object_2 = bpy.data.objects.new('WindowBoundingBox', mesh_2);
    context.scene.objects.link(mesh_object_2)
    mesh_object_2.location = mesh_object.location
    
    vertices = [
                (-w, -d, h),
                (w, -d, h),
                (w, -d, -h),
                (-w, -d, -h),
                (-w, d, h),
                (w, d, h),
                (w, d, -h),
                (-w, d, -h)
    ]
    
    edges = [
            (0, 1),
            (0, 3),
            (0, 4),
            (1, 5),
            (1, 2),
            (2, 6),
            (2, 3),
            (3, 7),
            (4, 5),
            (5, 6),
            (6, 7),
            (7, 4)
    ]
    
    mesh_2.from_pydata(vertices, edges, [])
    mesh_2.update()
    
    mesh_object_1.select = True
    mesh_object.select = True
    
    context.scene.objects.active = mesh_object
    bpy.ops.object.parent_set(type = 'OBJECT', keep_transform = True)
    
    mesh_object_1.select = False
    
    mesh_object_2.select = True
    bpy.ops.object.parent_set(type = 'OBJECT', keep_transform = True)
    
    mesh_object_2.select = False
    mesh_object.select = False

def create_object(self, context):
    
    # Deselect all objects before adding window object
    
    objects = context.scene.objects
    
    for ob in objects:
        ob.select = False
    
    # Add the window object
    
    # 1. Create the main object
    
    mesh = bpy.data.meshes.new('WindowMesh')
    mesh_object = bpy.data.objects.new('Window', mesh)
    context.scene.objects.link(mesh_object)
    mesh_object.location = context.scene.cursor_location
    
    mesh_object.window_property.add()
    
    #2. Generate window data based on window type
    
    window_type = mesh_object.window_property[0].window_type
    window-data = None
    
    if window_type == '1':
        window_data = window_type_1()
    elif window_type == '2':
        window_data = window_type_2()
    
    # generate_components(self, context)
    

def update_object(self, context):
    
    # Update the old mesh with the updated window attributes
    
    ob = context.object
    
    # Deselect all objects
    
    objects = context.scene.objects
    
    for o in objects:
        o.select = False
    
    oldmesh = ob.data
    oldname = ob.data.name
    temp_mesh = bpy.data.meshes.new(oldname + 'temp')
    
    w = ob.window_property[0].window_frame_width / 2
    h = ob.window_property[0].window_frame_height / 2
    d = ob.window_property[0].window_frame_depth / 2
    t = ob.window_property[0].window_frame_thickness
    gt = ob.window_property[0].glass_pane_thickness / 2
    
    if t > min(w, h):
        t = min(w, h)
                
    if gt > d:
        gt = d
    
    
    vertices = [
                (-w, -d, h),
                (w, -d, h),
                (w, -d, -h),
                (-w, -d, -h),
                (-w+t, -d, h-t),
                (w-t, -d, h-t),
                (w-t, -d, -h+t),
                (-w+t, -d, -h+t),
                (-w, d, h),
                (w, d, h),
                (w, d, -h),
                (-w, d, -h),
                (-w+t, d, h-t),
                (w-t, d, h-t),
                (w-t, d, -h+t),
                (-w+t, d, -h+t)
    ]
    
    faces = [
            (0, 4, 5, 1),
            (1, 5, 6, 2),
            (2, 6, 7, 3),
            (3, 7, 4, 0),
            (8, 12, 13, 9),
            (9, 13, 14, 10),
            (10, 14, 15, 11),
            (11, 15, 12, 8),
            (0, 1, 9, 8),
            (1, 2, 10, 9),
            (2, 3, 11, 10),
            (3, 0, 8, 11),
            (4, 12, 13, 5),
            (5, 13, 14, 6),
            (7, 6, 14, 15),
            (4, 7, 15, 12)
    ]
    
    temp_mesh.from_pydata(vertices, [], faces)
    temp_mesh.update()
    ob.data = temp_mesh
    temp_mesh.name = oldname
    
    children = ob.children
    
    old_mesh_1 = children[1].data
    old_name_1 = children[1].data.name
    temp_mesh_1 = bpy.data.meshes.new(old_name_1 + 'temp')
    
    vertices = [
                (-w+t, -gt, h-t),
                (w-t, -gt, h-t),
                (w-t, -gt, -h+t),
                (-w+t, -gt, -h+t),
                (-w+t, gt, h-t),
                (w-t, gt, h-t),
                (w-t, gt, -h+t),
                (-w+t, gt, -h+t)
    ]
    
    faces = [
            (0, 3, 2, 1),
            (4, 5, 6, 7),
            (0, 1, 5, 4),
            (1, 2, 6, 5),
            (2, 3, 7, 6),
            (3, 0, 4, 7)
    ]
    
    temp_mesh_1.from_pydata(vertices, [], faces)
    temp_mesh_1.update()
    children[1].data = temp_mesh_1
    temp_mesh_1.name = old_name_1
    
    old_mesh_2 = children[0].data
    old_name_2 = children[0].data.name
    temp_mesh_2 = bpy.data.meshes.new(old_name_2 + 'temp')
    
    vertices = [
                (-w, -d, h),
                (w, -d, h),
                (w, -d, -h),
                (-w, -d, -h),
                (-w, d, h),
                (w, d, h),
                (w, d, -h),
                (-w, d, -h)
    ]
    
    edges = [
            (0, 1),
            (0, 3),
            (0, 4),
            (1, 5),
            (1, 2),
            (2, 6),
            (2, 3),
            (3, 7),
            (4, 5),
            (5, 6),
            (6, 7),
            (7, 4)
    ]
    
    temp_mesh_2.from_pydata(vertices, edges, [])
    temp_mesh_2.update()
    children[0].data = temp_mesh_2
    temp_mesh_2.name = old_name_2
    
    ob.select = True
    context.scene.objects.active = ob
    
    bpy.data.meshes.remove(oldmesh)
    bpy.data.meshes.remove(old_mesh_1)
    bpy.data.meshes.remove(old_mesh_2)

def update_window_type(self, context):
    
    window_type = context.object.window_property[0].window_type
    # print(window_type)
    
    window_data = None
    if window_type == '1':
        window_data = window_type_1()
    elif window_type == '2':
        window_data = window_type_2()
        
    print(window_data)
    
window_type_items = (
    ('1', 'Picture Window', ''),
    ('2', 'Awning Window', ''),
    )
    
class WindowProperty(bpy.types.PropertyGroup):
    
    window_frame_width = bpy.props.FloatProperty(name = 'Window Width', default = 6.0, min = 1.0, max = 100.0, update = update_object, description = 'Width of the window')
    window_frame_height = bpy.props.FloatProperty(name = 'Window Height', default = 2.0, min = 1.0, max = 100.0, update = update_object, description = 'Height of the window')
    window_frame_thickness = bpy.props.FloatProperty(name = 'Window Thickness', default = 0.2, min = 0.1, update = update_object, description = 'Thickness of the window')
    window_frame_depth = bpy.props.FloatProperty(name = 'Window Depth', default = 0.4, min = 0.1, max = 100.0, update = update_object, description = 'Depth of the window')
    glass_pane_thickness = bpy.props.FloatProperty(name = 'Glass Pane Thickness', default = 0.01, min = 0.01, update = update_object, description = 'Thickness of the glass pane')
    
    window_type = bpy.props.EnumProperty(name = 'Window Type', items = window_type_items, update = update_window_type, description = 'Window Type')
    
#-------------------------------------------------
#   Register the property class
#-------------------------------------------------

bpy.utils.register_class(WindowProperty)
bpy.types.Object.window_property = bpy.props.CollectionProperty(type = WindowProperty)

class VIEW3D_PT_window_builder_config(bpy.types.Panel):
    
    bl_idname = 'VIEW3D_PT_window_builder_config'
    bl_label = 'Window Properties'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_description = 'Configure window object'
    bl_category = 'Builder'
    
    @classmethod
    def poll(cls, context):
        ob = context.object
        
        if ob is None:
            return False
        if 'window_property' not in ob:
            return False
        else:
            return True
    
    def draw(self, context):
        
        ob = context.object
        
        try:
            if 'window_property' not in ob:
                return
        except:
            return
        
        layout = self.layout
        window_properties = ob.window_property[0]
        layout.prop(window_properties, 'window_type')
        
        if window_properties.window_type == '1':
            layout_window_type_1(layout, window_properties)
        elif window_properties.window_type == '2':
            layout_window_type_2(layout, window_properties)
        

def window_type_1():
    return 1
    
def window_type_2():
    return 2
    
def layout_window_type_1(layout, window_properties):
    layout.prop(window_properties, 'window_frame_width')
    layout.prop(window_properties, 'window_frame_height')
    layout.prop(window_properties, 'window_frame_depth')
    layout.prop(window_properties, 'window_frame_thickness')
    layout.prop(window_properties, 'glass_pane_thickness')
    
def layout_window_type_2(layout, window_properties):
    layout.prop(window_properties, 'window_frame_width')
    layout.prop(window_properties, 'window_frame_height')